timeUI <- function(id) {
  ns <- NS(id)
  
  
}

time <- function(id, additional_arguments) {
moduleServer(id, function(input, output, session) {
  
  })
}